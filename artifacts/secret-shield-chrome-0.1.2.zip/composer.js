(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let current = null, locked = [], revision = 0;
  function invalidate() { $('result').value = ''; $('copy').disabled = true; }
  $('draft').addEventListener('input', () => {
    invalidate();
    $('result-status').textContent = 'Draft changed. Mask it again before copying.';
  });
  $('mask').addEventListener('click', () => {
    invalidate();
    try {
      if (!current) throw new Error();
      const result = SecretShieldCore.redact($('draft').value, current);
      $('result').value = result.text;
      $('copy').disabled = !result.text;
      $('result-status').textContent = result.count ? `${result.count} possible secret${result.count === 1 ? '' : 's'} masked. Review the result.` : 'No supported secret pattern found. Review the result; detection is not exhaustive.';
    } catch { $('result-status').textContent = 'Could not scan. Keep this text local and shorten it or reload the policy.'; }
  });
  $('clear').addEventListener('click', () => {
    $('draft').value = ''; invalidate(); $('result-status').textContent = 'Text cleared from this window.'; $('draft').focus();
  });
  $('copy').addEventListener('click', async () => {
    try {
      if (!current || $('copy').disabled) return;
      // Re-scan immediately before copying. Never copy the original draft.
      const result = SecretShieldCore.redact($('result').value, current);
      if (result.count) { invalidate(); throw new Error(); }
      await navigator.clipboard.writeText(result.text);
      $('result-status').textContent = 'Masked text copied. Your clipboard now contains this result.';
    } catch { $('result-status').textContent = 'Could not copy. Mask again or select the reviewed masked text manually.'; }
  });
  $('expand').addEventListener('click', () => { void chrome.runtime.openOptionsPage(); });
  async function reload() {
    const request = ++revision;
    current = null; invalidate(); $('mask').disabled = true; $('save').disabled = true;
    try {
      const loaded = await SecretShieldPolicy.loadPolicy();
      if (request !== revision) return;
      current = loaded.policy; locked = loaded.locked;
      $('mode').value = current.mode;
      $('client-ids').checked = current.protectClientIds;
      $('sensitive-names').value = current.sensitiveNames.join('\n');
      for (const [key, id] of [['mode', 'mode'], ['protectClientIds', 'client-ids'], ['sensitiveNames', 'sensitive-names']]) {
        $(id).disabled = locked.includes(key);
      }
      $('managed-label').textContent = locked.length ? 'Managed by your organization' : '';
      $('mask').disabled = false; $('save').disabled = locked.length === 3;
      $('result-status').textContent = 'Ready. Scanning runs entirely on this device.';
    } catch {
      if (request === revision) $('result-status').textContent = 'Policy unavailable. Scanning and copying are paused. Reload the extension.';
    }
  }
  $('save').addEventListener('click', async () => {
    try {
      const requested = SecretShieldCore.normalizePolicy({ mode: $('mode').value,
        protectClientIds: $('client-ids').checked,
        sensitiveNames: $('sensitive-names').value.split('\n').map(s => s.trim()).filter(Boolean) });
      const local = Object.fromEntries(Object.entries(requested).filter(([key]) => !locked.includes(key)));
      await chrome.storage.local.set({ policy: local });
      await reload();
      $('settings-status').textContent = 'Settings saved. Managed settings always take precedence.';
    } catch { $('settings-status').textContent = 'Could not save. Use up to 30 field names of 2–64 letters, digits, spaces, underscores or hyphens.'; }
  });
  chrome.storage.onChanged.addListener((_changes, area) => { if (area === 'local' || area === 'managed') void reload(); });
  async function coverage() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error();
      const state = await chrome.tabs.sendMessage(tab.id, { type: 'coverage' });
      $('coverage').textContent = state.ready && state.editors === 1 ? `${state.site} input recognized · prompt guard ready. Coverage is limited to supported input and send controls.` : `${state.site} · guard unavailable or input not recognized. Use this local composer.`;
    } catch { $('coverage').textContent = 'Local composer ready · Open ChatGPT or Claude in Chrome for supported input protection. Reload existing tabs after installing.'; }
  }
  void reload(); void coverage();
})();
