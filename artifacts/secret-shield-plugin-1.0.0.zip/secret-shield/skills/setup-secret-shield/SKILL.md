---
name: setup-secret-shield
description: Use when the user wants to install or evaluate CkretGuard's Chrome extension and custom secret field settings for ChatGPT and Claude, or understand its current secret-masking coverage.
---

# Set up CkretGuard

CkretGuard is published by Orenthic.

This is a setup companion. Installing this plugin alone does **not** intercept prompts. The bundled Chrome extension performs local pattern detection and gates recognized website send controls. It does not protect native ChatGPT, Codex, Claude desktop, Claude Code, files, images, voice, history, or arbitrary agent traffic.

Never ask the user to paste real credentials into chat, a tool argument, an issue, or a test. An LLM-based “scan my prompt” workflow would expose those values before redaction. Never claim this plugin can mask a message already submitted to the model. If a user has already shared a real key, avoid repeating it and recommend revoking/rotating it through the issuer.

## Install the browser component

The complete built extension is in `extension/` beside this SKILL.md. Read its `manifest.json` to verify the package version and supported origins. It is self-contained and requires no build or server.

In a local execution environment, locate this skill's `extension` directory and give the user its absolute path. Explain these steps:

1. In Chrome, open `chrome://extensions` and enable Developer mode.
2. Choose Load unpacked and select that directory.
3. Pin CkretGuard and reload existing ChatGPT/Claude browser tabs.
4. Open CkretGuard, type an optional Custom secret field such as dataset1, and click Save. Click the saved-field count below the input to view saved names. Repeat to add up to 50 fields; at the limit the input is hidden until a field is removed. Add field names only, never secret values.

If the host cannot expose local package files, explain that the browser extension must be downloaded/extracted onto the user's computer using a host-supported file delivery mechanism. Do not invent a download URL, claim installation, or copy the package to a cloud scanner. The extension is not automatically installed in Chrome by installing this AI plugin.

Do not modify browser profiles, install extensions, change site access, or alter organization policy as part of explaining setup unless the user explicitly requests those steps and the host supports them.

## Verify with synthetic data

Use `api_key = fictional-credential-123`, or save the custom field `dataset1` and use `dataset1 = fictional-value-123`. Never substitute a real credential. On recognized chat inputs, clicking Send or pressing Enter with this draft should cancel the send and open a warning with the single headline **1 secret detected**, with the number in red, and **Send**, **Edit**, and **Mask**. **Send** sends the unchanged draft for that one attempt. **Edit** sends nothing and focuses the unchanged draft. **Mask** replaces detected credential values with `xxxxx` and automatically sends the masked prompt once after a successful re-scan and revalidation of the current draft and policy. No second click is needed. Choosing Edit or Mask in protection settings automatically saves block mode: **Send** is absent from the popup, leaving **Edit** and **Mask** under the same validation requirements. Choosing Send, Edit, or Mask automatically saves the selection and restores all three actions. Pasting the example alone should not modify it; detection occurs at submission. The displayed count is the detected occurrence count, not confirmed leaks or a guarantee that every secret was found.

For a provider-free test, use the repository scanner tests or intercepted local browser fixtures. Sending even a synthetic prompt to an external AI chat requires the user's explicit instruction. Report browser installation and active coverage only after observing them.

## Explain limits accurately

Browser pages can read raw text typed into their own inputs before sending. Detection targets credentials such as keys, passwords, client IDs, client secrets, tokens, and private keys; it does not classify general confidential prose. Detection is pattern-based, not exhaustive; arbitrary unlabeled client IDs and encoded/split secrets may be missed. A client ID is not always confidential, so named client ID protection is configurable. Built-in multiword field names accept case-insensitive joined/camelCase, spaces/tabs, hyphens, underscores, and repeated or mixed separators between words. For example, apiToken, api-token, api token, and api_token match the same rule. Client-ID variants all follow the client-ID setting. Assignments require =, :, is, or the fullwidth equivalents ＝/：. Values may follow on the next line. Straight and curly quotes retain spaces inside values, including Bearer/Basic tokens, and nonbreaking horizontal spaces are accepted. Unquoted values stop at whitespace, so values containing spaces must be quoted. Separator-free phrases, misspelled field names, and grouped field-name lists followed by unlabeled value lines are not supported. Custom names remain literal apart from capitalization. Known placeholders are skipped. Browser scanning covers the full current prompt, including drafts above 100,000 characters; it does not truncate text or change the website’s input or model context limits. Excessive scan work still blocks recognized sending. Scan and policy failures cannot be bypassed with the **Send** choice.

The content-script guard covers only recognized input/send event paths and can be bypassed by changed UI, page scripts, other extensions, disabled or restricted site access, and unsupported sources. It is not a network interception layer or a tamper-proof enterprise control.

Only policy preferences and three aggregate numeric activity counters are stored locally; there is no backend, remote telemetry, raw prompt logging, or secret vault. The counters summarize detected secret occurrences, prompts forwarded after Mask, and prompts forwarded unchanged after Send. Each sending action counts one prompt, regardless of the number of secrets. Saving custom fields does not increment detection or send counts. They count repeated attempts and do not identify unique keys or confirm provider delivery. Custom sensitive names are literal labels, not secret values. Up to 50 names are saved locally. Newly added names require 3–64 letters, digits, spaces, underscores or hyphens, starting with a letter; existing two-character policy names remain supported. Assigning a value to a saved field using =, :, or is triggers review; adding a bare field name or an unrelated unlabeled value does not. Click × beside a saved name to stop protecting that custom field. Managed names cannot be edited locally. Read [enterprise guidance](references/ENTERPRISE.md) for policy and production-readiness requirements. This build is an engineering pilot; do not describe it as audited, certified, enterprise-complete, or universally compatible.
